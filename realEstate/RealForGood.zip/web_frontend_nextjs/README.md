# React.js with Next.js Web Frontend

This folder contains the web frontend built with React.js and Next.js.