# Django Backend

This folder contains the Django backend for RealForGood.