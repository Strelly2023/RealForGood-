# Database Configuration

This folder contains configuration details for PostgreSQL and Redis.