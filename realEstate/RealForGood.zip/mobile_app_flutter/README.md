# Flutter Mobile App

This folder contains the Flutter mobile app for RealForGood.