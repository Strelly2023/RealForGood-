# Firebase Authentication

This folder contains Firebase Auth setup instructions.